window.onload = function carrinho(){
    var carrinho2 = document.getElementById('carrinho2');
    exibirCarrinho(carrinho2);
}
function addCarrinho(nome, preco, qtdparcelamento,quantidade,posicao){ 
    localStorage.setItem("nome"+posicao, nome); 
    localStorage.setItem("preco"+posicao, preco);   
    localStorage.setItem("quantidade"+posicao, quantidade);
    localStorage.setItem("qtdparcelamento"+posicao,qtdparcelamento);
    console.log(nome);
}
function exibirCarrinho(carrinho2){
for(var i=1; i <=100; i++)
if(localStorage.getItem('nome' +i) !=null){
    carrinho2.innerHTML += "<table><hr>Produto:  "+localStorage.getItem('nome'+i)+
    "<hr>.Preço:  "+localStorage.getItem('preco'+i)+
    "<hr>Quantidade:  "+localStorage.getItem('quantidade'+i)+
    "<hr>QtdParcelamento:  "+localStorage.getItem('qtdparcelamento'+i)+"<hr>"+
    "<label for='text'>Adicionar mais produtos ao Carrinho</label>"+
    "<br></br>"+"<input type='button' value='Adicionar'></input>"+
    "<br></br>"+"<label for='text'>Excluir item do Carrinho</label>"+"<br></br>"+
    "<input type='button' value='Excluir'></input>";

    }                   
}
function exlcuirItem(nome,preco,quantidade,posicao){
    localStorage.removeItem(nome + posicao);
    localStorage.removeItem(preco + posicao);
    localStorage.removeItem(quantidade + posicao);
    console.removeItem(nome);
}
function addcadastro(nome,email,nascimento,senha,confirmacaosenha,cpf,posicao){
    localStorage.setItem("nome" + posicao,nome);
    localStorage.setItem("nascimento" + posicao,nascimento);
    localStorage.setItem("email" +posicao,email);
    localStorage.setItem("senha" + posicao,senha);
    localStorage.setItem("confimacaosenha" + posicao,confirmacaosenha);
    localStorage.setItem("cpf" + posicao,cpf);
}
    function cpf(cpf) {
        var Soma;
        var Resto;
        Soma = 0;
      if (cpf == "00000000000") return false;
      for (i=1; i<=9; i++) Soma = Soma + parseInt(cpf.substring(i-1, i)) * (11 - i);
      Resto = (Soma * 10) % 11;
        if ((Resto == 10) || (Resto == 11))  Resto = 0;
        if (Resto != parseInt(cpf.substring(9, 10)) ) return false;
      Soma = 0;
        for (i = 1; i <= 10; i++) Soma = Soma + parseInt(cpf.substring(i-1, i)) * (12 - i);
        Resto = (Soma * 10) % 11;
        if ((Resto == 10) || (Resto == 11))  Resto = 0;
        if (Resto != parseInt(cpf.substring(10, 11) ) ) return false;
        return true;
    }
    var cpf= "12345678909";

   
    function validadata(){
        var data = document.getElementById("nascimento").value; 
        data = data.replace(/\//g, "-"); 
        var data_array = data.split("-"); 
        if(data_array[0].length != 4){
           data = data_array[2]+"-"+data_array[1]+"-"+data_array[0]; 
        }
        var hoje = new Date();
        var nascimento  = new Date(data);
        var idade = hoje.getFullYear() - nascimento.getFullYear();
        var m = hoje.getMonth() - nascimento.getMonth();
        if (m < 0 || (m === 0 && hoje.getDate() < nascimento.getDate())) idade--;
        if(idade < 18){
           alert("Pessoas  que forem menores de 18 não conseguem se cadastrar.");
           return false;
        }
        if(idade >= 18 && idade <= 60){
           alert("Pessoas semdo maiores de 18, pode se cadastrar.");
           return true;
        }
        return false;
    }
   console.log(nome);
   var nome = /\b[A-Za-zÁ-ú]+,?\s[A-Za-zÁ-ú][A-Za-zÁ-ú]{2,19}\b/;
   
   function validateEmail(email) {
    var re = /\S+@\S+\.\S+/;
    return re.test(email);
  }
      
  
    function validarEmail(){
        var email = document.querySelector('#email');
        var error = document.querySelector('#error-email');
        
        if(!email.checkValidity()){
          error.innerHTML = "Email invalido";  
        }
         
      }
      
      function redefinirMsg(){
        var error = document.querySelector('#error-email');
        if (error.innerHTML == "Email invalido"){
          error.innerHTML = "";
        }
      }
      function calculartotal(){
        var produtos = document.getElementsByClassName("produtos");
        var totaldeprodutos = 0;
        for(var pos = 0; pos< produtos.length;pos++){
          var princeElements = produtos[pos].ATTRIBUTE_NODE
          getElementsByClassName("price");
          var princeText = princeElements[0].innerHTML;
        var price = moneyTextToFloat(princeText);
      var qtdElements = produtos[pos]. 
    getElementsByClassName("quantity");
  var qtdText = qtdElements[0].value;
var quantity = moneyTextToFloat(qtyText);
var subtotal = quantity * price;
totaldeprodutos += subtotal;
      }
      return totaldeprodutos
      }
      ShopifyBuy.UI.onReady(client).then(function (ui) {
        ui.createComponent('product', {
          id: 12345,
          options: {
            product: {
              buttonDestination: 'cart',
              contents: {
                description: true
              },
              text: {
                button: 'Add to Cart'
              },
              styles: {
                button: {
                  'background-color': 'blue'
                }
              }
            },
            cart: {
              styles: {
                button: {
                  'background-color': 'orange'
                }
              }
            }
          }
        });
      });
    
      